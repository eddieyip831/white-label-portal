import { list } from "~/lib/rbac/__RBAC__"; // placeholder to be replaced by script

export default async function Page() {
  const data = await list();

  return (
    <div className="p-6">
      <pre>{JSON.stringify(data, null, 2)}</pre>
    </div>
  );
}
