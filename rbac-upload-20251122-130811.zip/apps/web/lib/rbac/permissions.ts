// apps/web/lib/rbac/permissions.ts

import { getSupabaseServerAdminClient } from "@kit/supabase/server-admin-client";

export async function getAllPermissions() {
  const supabase = getSupabaseServerAdminClient();
  const { data, error } = await supabase
    .from("permissions")
    .select("*")
    .order("name");

  if (error) throw error;
  return data;
}

export async function getRolePermissions(roleId: string) {
  const supabase = getSupabaseServerAdminClient();
  const { data, error } = await supabase.rpc("get_role_permissions", {
    role_id: roleId,
  });

  if (error) throw error;
  return data;
}

export async function assignPermission(roleId: string, permissionId: string) {
  const supabase = getSupabaseServerAdminClient();
  const { error } = await supabase.from("role_permissions").insert({
    role_id: roleId,
    permission_id: permissionId,
  });

  if (error) throw error;
}
