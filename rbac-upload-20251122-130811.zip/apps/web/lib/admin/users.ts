// apps/web/lib/admin/users.ts
import { getSupabaseServerAdminClient } from '@kit/supabase/server-admin-client';

type AdminUser = {
  id: string;
  email: string | null;
  created_at: string;
};

export async function listAdminUsers(): Promise<AdminUser[]> {
  // Optional: warn loudly if the service role key is missing in this environment
  if (!process.env.SUPABASE_SERVICE_ROLE_KEY) {
    console.error(
      '[AdminUsers] SUPABASE_SERVICE_ROLE_KEY is not set – admin users API will fail (auth.admin.listUsers).',
    );
  }

  const supabase = getSupabaseServerAdminClient();

  // auth.users is only accessible via the Admin client
  const { data, error } = await supabase.auth.admin.listUsers({
    page: 1,
    perPage: 50,
  });

  if (error) {
    console.error('[AdminUsers] Error loading users from Supabase:', error);
    throw error;
  }

  return (data?.users ?? []).map((u) => ({
    id: u.id,
    email: u.email ?? null, // normalize undefined → null to match AdminUser type
    created_at: u.created_at,
  }));
}
