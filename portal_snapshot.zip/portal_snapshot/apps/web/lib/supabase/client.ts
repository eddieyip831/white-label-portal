import { createBrowserClient } from '@kit/supabase/browser-client';

export const supabase = createBrowserClient();
