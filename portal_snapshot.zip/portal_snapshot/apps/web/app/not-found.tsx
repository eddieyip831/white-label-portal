"use client";
import FallbackError from "~/components/FallbackError";

export default function NotFound() {
  return <FallbackError />;
}
