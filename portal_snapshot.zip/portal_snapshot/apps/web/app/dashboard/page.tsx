export default function DashboardPage() {
  return (
    <div>
      <h1>Dashboard</h1>
      <p>Portal home/dashboard. Future modules can plug widgets here.</p>
    </div>
  );
}
