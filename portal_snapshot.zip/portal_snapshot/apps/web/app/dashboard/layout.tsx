import UserShell from '~/components/layout/UserShell';

export default function DashboardLayout({ children }) {
  return <UserShell>{children}</UserShell>;
}
