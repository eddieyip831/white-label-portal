export default function UsersListPage() {
  return (
    <div>
      <h1>Users</h1>
      <p>
        This is a placeholder for the Users module list page. In the framework,
        this will be driven by configuration (columns, filters, actions).
      </p>
    </div>
  );
}
